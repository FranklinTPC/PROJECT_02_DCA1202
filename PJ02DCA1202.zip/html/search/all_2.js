var searchData=
[
  ['limpavoxels_0',['limpaVoxels',['../class_sculptor.html#a9469483f9acf169fc90d23997bea7ee8',1,'Sculptor']]]
];
