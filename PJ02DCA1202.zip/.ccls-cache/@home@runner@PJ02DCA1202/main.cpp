#include "sculptor.hpp"
#include <iostream>

int main(void) {
  Sculptor Crepper(200, 200, 200);
  Crepper.setColor(0, 1, 0, 1); // Define a cor para verde

  // Cria o corpo do Creeper
  ///////////////x0,x1,y0,y1,z0,z1//////////////////////
  Crepper.putBox(80, 120, 20, 68, 60, 160);
  Crepper.cutBox(81, 119, 21, 67, 61, 159);//OCO INTERNO

  // Cria a cabeça do Creeper
  Crepper.putBox(72, 128, 20, 68, 160, 200);
  Crepper.cutBox(72, 77, 38, 33, 160, 175); // direita
  Crepper.cutBox(72, 77, 50, 55, 160, 175); // esquerda
  Crepper.cutBox(72, 77, 39, 49, 165, 180); // meio
  Crepper.cutBox(72, 77, 38, 27, 180, 190);  // OLHO DIR
  Crepper.cutBox(72, 77, 50, 61, 180, 190); // OLHO ESQ
  
  // Detalhes do rosto
  Crepper.setColor(0, 0, 0, 1);             // Define a cor para preto
  Crepper.putBox(76, 77, 38, 33, 160, 175); // direita
  Crepper.putBox(76, 77, 50, 55, 160, 175); // esquerda
  Crepper.putBox(76, 77, 39, 49, 165, 180); // meio
  Crepper.putBox(76, 77, 38, 27, 180, 190);  // OLHO DIR
  Crepper.putBox(76, 77, 50, 61, 180, 190); // OLHO ESQ
  Crepper.cutBox(78, 127, 21, 67, 161, 180); // OCO INTERNO

  Crepper.setColor(0, 1, 0, 1); // Define a cor para verde

  // Cria as pernas do Creeper
  Crepper.putBox(60, 80, 20, 43, 20, 60);
  Crepper.putBox(120, 140, 20, 43, 20, 60);
  Crepper.putBox(60, 80, 45, 68, 20, 60);
  Crepper.putBox(120, 140, 45, 68, 20, 60);

  // Cores nos pes do creeper
  Crepper.setColor(0, 0, 0, 1); // Define a cor para preto

  Crepper.putBox(60, 59, 20, 43, 20, 30);
  Crepper.putBox(120, 121, 20, 43, 20, 30);
  Crepper.putBox(60, 59, 45, 68, 20, 30);
  Crepper.putBox(120, 121, 45, 68, 20, 30);

  Crepper.putBox(60, 63, 20, 43, 20, 23);
  Crepper.putBox(120, 123, 20, 43, 20, 23);
  Crepper.putBox(60, 63, 45, 68, 20, 23);
  Crepper.putBox(120, 123, 55, 68, 20, 23);

  Crepper.setColor(0.58,0.29,0,1); // Define a cor para marrom

  Crepper.putBox(40, 160,0, 90, 21, 1);
  Crepper.cutBox(41, 159, 1, 89, 20, 2);// OCO INTERNO
  // Salva o desenho em um arquivo .OFF
  Crepper.writeOFF("creeper.off");

  return 0;
}
